#include "stdafx.h"
#include "Player.h"
#include "InputManager.h"


Player::Player(const wchar_t* path,
		BulletManager* bm)
:GameObject(path), bm(bm)
{
	moveSpeed = 3.0f;
}

void Player::Update()
{
	if (InputManager::GetKeyState(VK_UP))
		transform->position.y -= moveSpeed;
	if (InputManager::GetKeyState(VK_DOWN))
		transform->position.y += moveSpeed;
	if (InputManager::GetKeyState(VK_RIGHT))
		transform->position.x += moveSpeed;
	if (InputManager::GetKeyState(VK_LEFT))
		transform->position.x -= moveSpeed;
	if (InputManager::GetKeyDown(VK_SPACE))
	{
		Shoot();
	}
}


Player::~Player()
{
}


void Player::Shoot()
{
	for (float i = 0.72f; i <= 0.78f; i += 0.03f)
	{
		CreateBullet(300.0f, i);//i
	}
}
void Player::CreateBullet(float speed, float angle)
{
	Bullet* b = bm->PushBackPlayerBullet(
		new Bullet(L"bullet.png", speed,
		1.0f, angle, 0.0f, 1.0f)
		);
	b->transform->position
		= transform->position;
	//b->transform->SetScale(0.1f, 0.1f);
}