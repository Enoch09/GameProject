#pragma once
#include "GameObject.h"
#include "BulletManager.h"
#include "CircleCollider.h"
class Enemy :
	public GameObject
{
public:
	Enemy(const wchar_t* path,
		BulletManager* bm);
	~Enemy();

	float hp;
	void Hit(float damage);
	
	CircleCollider* col;
	BulletManager* bm;
};

